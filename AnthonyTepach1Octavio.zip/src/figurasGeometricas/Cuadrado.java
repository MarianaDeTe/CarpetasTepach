package figurasGeometricas;

/**
 * clase que hereda de Figura,se implementan los métodos que no se implementaron
 * en la clase abstracta
 *
 * @author anthonytepach
 */
public class Cuadrado extends Figura {

    public Cuadrado() {

    }

    public Cuadrado(double lado) {
        setValorLado(lado);
    }

    /**
     * hace la operación para sacar el área del cuadrado
     *
     * @return
     */
    @Override
    public double obtenerArea() {
        setArea(getValorLado() * getValorLado());
        return getArea();
    }

    /**
     * hace la operación para sacar el perimetro del cuadrado
     *
     * @return
     */
    @Override
    public double obtenerPerimetro() {
        setPerimetro(getValorLado() * 4);
        return getPerimetro();
    }

}
