package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class TablaPDF {

    /**
     * ejemplo de creacion de tablas
     */
    public void generaTabla() {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Tabla.pdf"));
            doc.open();
            PdfPTable mitabla = new PdfPTable(3);//el constructor recibe el número de columnas
            mitabla.addCell("celda 1");//con addcell agregas una celda, el PDF solo se genera si si se llenan las 3 columnas 
            mitabla.addCell("celda 2");
            mitabla.addCell("celda 3");
            mitabla.addCell("celda 4");
            mitabla.addCell("celda 3");
            mitabla.addCell("celda 3");
            doc.add(mitabla);
            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * genera tabla especificando desde un formulario grafico las filas y las
     * columnas
     *
     * @param colum
     * @param fila
     */
    public void generaTabla(int colum, int fila) {

        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Tabla.pdf"));
            doc.open();
            PdfPTable mitabla = new PdfPTable(colum);//el constructor recibe el número de columnas
            for (int i = 0; i < fila; i++) {
                mitabla.addCell("fila ".concat(String.valueOf(i + 1)));
                for (int j = 1; j < colum; j++) {
                    mitabla.addCell("celda ".concat(String.valueOf(i + 2)));
                }
            }
            doc.add(mitabla);
            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public static void main(String[] args) {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Tabla.pdf"));
            doc.open();
            PdfPTable mitabla = new PdfPTable(3);//el constructor recibe el número de columnas
            PdfPCell celda = new PdfPCell();
            celda.setColspan(3);
            Paragraph parrafo = new Paragraph("Titulo");
            parrafo.setAlignment(Element.ALIGN_CENTER);
            celda.addElement(parrafo);
            mitabla.addCell(celda);
            mitabla.addCell("celda 1");
            mitabla.addCell("celda 2");
            mitabla.addCell("celda 3");
            doc.add(mitabla);
            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
