/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;

import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;


/**
 *
 * @author Alumnos
 */
public class AlinearParrafos {
    public static void main (String [] args){
        try {
            Paragraph parrafo = new Paragraph();
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("tercer.pdf"));
            doc.open();//
            parrafo.setAlignment(Element.ALIGN_CENTER);
            doc.add(parrafo);
            for (int i = 1; i <= 20; i++) {
                
                Paragraph parrafo2 = new Paragraph("Párrafo  n° " + i);
                if ((i % 2) == 1) {
                    parrafo2.setAlignment(Element.ALIGN_LEFT);//alinea el parrado a la izquierda
                } else if ((i % 2 == 0)) {
                    parrafo2.setAlignment(Element.ALIGN_RIGHT);//alinea el parrado a la derecha
                }
                doc.add(parrafo2);
//                doc.add(new Paragraph("Párrafo izquierda n° " + i ));
//                Paragraph parrafo3 = new Paragraph("Párrafo derecha n° " + i);
//                parrafo3.setAlignment(Element.ALIGN_RIGHT);
//                doc.add(parrafo3);

            }
            
            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
