package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 *
 * @author AnthonyTepach
 */
public class PDFdesdeForm {

    /**
     * Método que recibe como parámetros titulo y Parrafo de tipo String cuyos
     * son mandados de FormularioPDF donde “titulo” se concatena con “.pdf” para
     * generar el PDF.La instancia anónima “paragraph” recibe como parámetro a
     * Parafo este agrega el párrafo al PDF.
     * @param titulo
     * @param Parrafo
     */
    public void generaPDF(String titulo, String Parrafo) {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream(titulo + ".pdf"));
            doc.open();
            doc.add(new Paragraph(Parrafo));
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
