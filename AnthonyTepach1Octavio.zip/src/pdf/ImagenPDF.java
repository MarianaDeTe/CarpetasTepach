/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;

import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;


/**
 *
 * @author Alumnos
 */
public class ImagenPDF {

    public static void main(String[] args) {
        try {
            Paragraph parrafo = new Paragraph();
            Document docc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(docc, new FileOutputStream("imagen.pdf"));
            docc.open();
            Image img = Image.getInstance("Koala.jpg");
            docc.add(img);
             Image imgDos = Image.getInstance("Koala.jpg");
            imgDos.scalePercent(20);
            docc.add(imgDos);
                    Image img3 = Image.getInstance("Koala.jpg");
            img3.scalePercent(10);
            img3.setAbsolutePosition(30, 10);
            docc.add(img3);
            docc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
