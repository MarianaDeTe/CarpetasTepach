/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fisica;

/**
 *
 * @author Alumnos
 */
public class Fisica {

    private double fuerza, masa, acelecion;

    /**
     * @return the fuerza
     */
    public double getFuerza() {
        return fuerza;
    }

    /**
     * @param fuerza the fuerza to set
     */
    public void setFuerza(double fuerza) {
        this.fuerza = fuerza;
    }

    /**
     * @return the masa
     */
    public double getMasa() {
        return masa;
    }

    /**
     * @param masa the masa to set
     */
    public void setMasa(double masa) {
        this.masa = masa;
    }

    /**
     * @return the acelecion
     */
    public double getAcelecion() {
        return acelecion;
    }

    /**
     * @param acelecion the acelecion to set
     */
    public void setAcelecion(double acelecion) {
        this.acelecion = acelecion;
    }

    /**
     * método que calcula la fuerza multiplicando masa por aceleracion
     *
     * @return un booleano en este caso fuerza
     */
    public double fuerza() {
        setFuerza(getMasa() * getAcelecion());

        return getFuerza();

    }

    /**
     * método que calcula la masa dividiendo fuerza entre aceleracion
     *
     * @return un booleano en este caso masa
     */
    public double masa() {
        setMasa(getFuerza() / getAcelecion());

        return getMasa();

    }

    /**
     * método que calcula la aceleracion dividiendo fuerza entre masa
     *
     * @return un booleano en este caso aceleracion
     */
    public double Aceleracion() {
        setAcelecion((getFuerza()) / (getMasa()));
        return getAcelecion();

    }
}
