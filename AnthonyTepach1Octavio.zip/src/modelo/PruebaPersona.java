package modelo;

public class PruebaPersona {

    public static void main(String[] args) {
        Persona objPersona = new Persona();

//        Persona obj2Persona=new Persona("Ana");
//        objPersona.setNombre("JUANITO");
//        System.out.println(objPersona.getNombre());
//        System.out.println(obj2Persona.getNombre());
//        Persona obj3=new Persona(1);
//        System.out.println(obj3.getNombre().toUpperCase());
//        System.out.println(obj3.getPaterno().toUpperCase());
//        System.out.println(obj3.getMaterno().toUpperCase());
//        System.out.println(obj3.getCurp().toUpperCase());
//        objPersona.getPersonaByPreparedStatement(2);
//        System.out.println(objPersona.getPersonaID()+" ".concat(objPersona.getNombre().concat(" "+objPersona.getPaterno().concat(" "+objPersona.getMaterno().concat(" "+objPersona.getCurp())))));
//        objPersona.eliminarPreparedSatatement(2);
        System.out.println(objPersona.getCurp());
//       objPersona.getPersonaByCallable(1);
        System.out.println(objPersona.getCurp());

    }
}
