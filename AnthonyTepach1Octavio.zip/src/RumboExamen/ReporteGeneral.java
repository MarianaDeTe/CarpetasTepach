/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RumboExamen;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;
import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Alumnos
 */
public class ReporteGeneral {

    private String Nombre, curp, apat, amat;
    private int Id;
    private ResultSet resul;

    public boolean getPersonaByPreparedStatement() {

        try {
            String sql = "select * from persona where personaid=? or nombre=? or paterno=? or materno=?";
            Conexion objConexion = new Conexion();
            PreparedStatement ps = objConexion.obtenerConexion().prepareStatement(sql);
            ps.setInt(1, getId());
            ps.setString(2, getNombre());
            ps.setString(3, getApat());
            ps.setString(4, getAmat());
            System.out.println(sql);
            resul = ps.executeQuery();
            try {
                Document doc = new Document(PageSize.LETTER);
                PdfWriter.getInstance(doc, new FileOutputStream("Reporte en tabla.pdf"));
                doc.open();
                Paragraph parrafo = new Paragraph();
                Font fuente = new Font();
                fuente.setColor(255, 100, 96);
                fuente.setSize(30);
                parrafo.setAlignment(Element.ALIGN_CENTER);
                parrafo.setFont(fuente);
                parrafo.add("\nReporte General");
                doc.add(parrafo);
                PdfPTable mitabla = new PdfPTable(2);
                doc.add(new Paragraph("\n\n"));
                mitabla.addCell("Nombre Completo");
                mitabla.addCell("CURP");
                while (resul.next()) {
                mitabla.addCell(resul.getString(2)+" "+resul.getString(3)+" "+resul.getString(4));
                    mitabla.addCell (resul.getString(5));
            }
                

                doc.add(mitabla);

                doc.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }

    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;

    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the curp
     */
    public String getCurp() {
        return curp;
    }

    /**
     * @param curp the curp to set
     */
    public void setCurp(String curp) {
        this.curp = curp;
    }

    /**
     * @return the apat
     */
    public String getApat() {
        return apat;
    }

    /**
     * @param apat the apat to set
     */
    public void setApat(String apat) {
        this.apat = apat;
    }

    /**
     * @return the amat
     */
    public String getAmat() {
        return amat;
    }

    /**
     * @param amat the amat to set
     */
    public void setAmat(String amat) {
        this.amat = amat;
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }

    /**
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }

}
