/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.Format; 

/**
 *
 * @author DIN
 */
public class GetSetDatos {
     private String nom, movimiento,horaEn,horaSal;
      Date he,hs;
     
            
    public String getHoraEn() {
        return horaEn;
    }

    public void setHoraEn(String horaEn) {
        this.horaEn = horaEn;
    }

    public String getHoraSal() {
        return horaSal;
    }

    public void setHoraSal(String horaSal) {
        this.horaSal = horaSal;
    }
    private int turno;

    public int getTurno() {
        return turno;
        
    }

    public void setTurno(int turno) {
             this.turno = turno;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(String movimiento) {
        this.movimiento = movimiento;
    }
     public String getHoraActual() {
        SimpleDateFormat formateador = new SimpleDateFormat("hh:mm:ss aa");
        return  formateador.format(new Date());
    }
     @Override
    public String toString() {
        return "Hora entrada: " + getHoraEn()+"\nTurno: " + getTurno()+ "\nNombre: " + getNom()+"\nMovimiento: "+getMovimiento()+"\n----------------";
    }
    
}
