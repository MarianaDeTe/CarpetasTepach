/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banco;

import java.util.LinkedList;
import java.util.Queue;

public class Cola {
    Queue<Object> cola=new LinkedList();

    public Queue<Object> getCola() {
        return cola;
    }

    public void setCola(Queue<Object> cola) {
        this.cola = cola;
    }
       

}
