/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import java.awt.FlowLayout;
import java.awt.HeadlessException;
import javax.swing.JApplet;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author AnthonyTeach
 */
public class MVCDemo extends JApplet {// jApplet es una interfas abstracta

    private JButton jbtController = new JButton("Muestra Controlador");// se crea boton 
    private JButton jbtView = new JButton("Muestra Vista");// se crea boton
    private ModeloCirculo model = new ModeloCirculo();// se crea un nuevo objeto instanciando al contructor

    public MVCDemo() {//constructor
        setLayout(new FlowLayout());// se agrega layout
        add(jbtController);//se agrega el boton controller a la interfaz
        add(jbtView);
        jbtController.addActionListener(new ActionListener() {// accion del boton Controller
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Controller");//se crea un nuevo jFrame
                ControladorCirculo controller = new ControladorCirculo();// se crea un objeto y se instancia el controlador por defecto
                controller.setModel(model);
                frame.add(controller);
                frame.setSize(200, 200);//tamaño del frame
                frame.setVisible(true);//hace visible el frame
            }
        });
        jbtView.addActionListener(new ActionListener() {//accion del boton View
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame();//se crea un nuevo jFrame
                VistaCirculo controller = new VistaCirculo();// se crea un objeto y se instancia el controlador por defecto
                controller.setModel(model);
                frame.add(controller);
                frame.setSize(200, 200);//tamaño del frame
                frame.setLocation(200, 200);//indica la posicion donde se debe mostra el Frame
                frame.setVisible(true);//hace visible el frame
            }
        });

    }

}
