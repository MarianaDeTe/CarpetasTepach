/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Alumnos
 */
public class ModeloCirculo {

    private double radius = 20;
    private boolean filled=true;
    private Color color;
    private ArrayList<ActionListener> actionListenerList;//arraylist que guanda los ActionListener de los objetos
    
    public double getRadius() {
        return radius;
    }
    
    public void setRadius(double radius) {
        this.radius = radius;
        processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "radius"));
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
        processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "filled"));
    }

    public java.awt.Color getColor() {
        return color;
    }

    public void setColor(java.awt.Color color) {
        this.color = color;
        processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "color"));
    }
    /**
     * agrega el ActionListener a un arraylist
     * @param l ActionListener recibido
     */
    public synchronized void addActionListener(ActionListener l) {
        if (actionListenerList == null) {
            actionListenerList = new ArrayList<>();
            actionListenerList.add(l);
        }
    }
    /**
     * elimina ActionListener del arraylist
     * @param l ActionListener recibido
     */
    public synchronized void removeActionListener(ActionListener l) {
        if (actionListenerList != null && actionListenerList.contains(l)) {
            actionListenerList.remove(l);
        }
    }
    
    private void processEvent(ActionEvent e) {
        ArrayList list;
        synchronized (this) {
            if (actionListenerList == null) {
                return;
            }
            list = (ArrayList) actionListenerList.clone();
        }
        for (int i = 0; i < list.size(); i++) {
            ActionListener listener = (ActionListener) list.get(i);
            listener.actionPerformed(e);
        }
    }
}
