package exam;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;

import java.io.FileOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ExamenTepach {

    private String Nombre, curp, apat, amat, sexo;
    private int Id;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getApat() {
        return apat;
    }

    public void setApat(String apat) {
        this.apat = apat;
    }

    public String getAmat() {
        return amat;
    }

    public void setAmat(String amat) {
        this.amat = amat;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public void creaPDF() {
        try {
            String SQL = "SELECT * FROM PERSONA WHERE PERSONAID=? OR NOMBRE=? OR PATERNO=? OR MATERNO=?";
            Conexion conet = new Conexion();
            PreparedStatement PS = conet.obtenerConexion().prepareStatement(SQL);
            PS.setInt(1, getId());
            PS.setString(2, getNombre());
            PS.setString(3, getApat());
            PS.setString(4, getAmat());
            ResultSet resultado = PS.executeQuery();

            Document documento = new Document(PageSize.LETTER);
            PdfWriter.getInstance(documento, new FileOutputStream("ExamenTepachReyes.pdf"));
            documento.open();
            Paragraph TITULO = new Paragraph();
            Font fuenteTitulo = new Font();
            fuenteTitulo.setColor(BaseColor.ORANGE);
            fuenteTitulo.setSize(30);
            TITULO.setFont(fuenteTitulo);
            TITULO.setAlignment(Element.ALIGN_CENTER);
            TITULO.add("-EXAMEN TepachReyesBryanAnthony-\n\n\n");
            documento.add(TITULO);
            PdfPTable TABLA = new PdfPTable(3);
            TABLA.addCell("N°");
            TABLA.addCell("Nombre");
            TABLA.addCell("CURP");
            Font ROJO = new Font();
            Font AZUL = new Font();
            ROJO.setColor(BaseColor.RED);
            AZUL.setColor(BaseColor.BLUE);
            BaseColor co;
            while (resultado.next()) {
                if ((resultado.getInt(1) % 2) == 0) {

                    TABLA.addCell(new Paragraph(String.valueOf(resultado.getInt(1)), AZUL));
                    TABLA.addCell(new Paragraph(resultado.getString(2) + " " + resultado.getString(3) + " " + resultado.getString(4), AZUL));
                    TABLA.addCell(new Paragraph(resultado.getString(5), AZUL));

                } else if ((resultado.getInt(1) % 2) == 1) {

                    TABLA.addCell(new Paragraph(String.valueOf(resultado.getInt(1)), ROJO));
                    TABLA.addCell(new Paragraph(resultado.getString(2) + " " + resultado.getString(3) + " " + resultado.getString(4), ROJO));
                    TABLA.addCell(new Paragraph(resultado.getString(5), ROJO));

                }

            }

            documento.add(TABLA);

            documento.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
