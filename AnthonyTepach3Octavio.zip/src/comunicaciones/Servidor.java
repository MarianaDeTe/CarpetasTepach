/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author AnthonyTepach
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            ServerSocket servidor = new ServerSocket(5000);
            System.out.println("Escucha en el puerto: " + servidor.getLocalPort());
            DataOutputStream dt;
            for (int i = 0; i <= 3; i++) {//espera recibir la solicitud
                Socket sc = servidor.accept();
                dt = new DataOutputStream(sc.getOutputStream());//flujo de salida = socket
                System.out.println("sirvo al cliente: " + i);//impresion del servidor
                dt.writeUTF("(°U°)/ hola cliente: " + i);
                dt.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
