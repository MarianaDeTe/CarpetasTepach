
package comunicaciones;

import java.io.File;


/**
 *clase que solo recupera la lista de los archivos de un directorio
 * @author AnthonyTepach
 */
public class Archivos {

    File f = new File("C:\\Users\\Alumnos\\Downloads\\ArchivosServidor");

    /**
     *
     * @return
     */
    public File[] Listar() {
        File[] g = f.listFiles();
        return g;
    }

    public static void main(String[] args) {
        Archivos a = new Archivos();
        a.Listar();
    }

}
