/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;


/**
 *
 * @author Alumnos
 */
public class ClienteFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Socket cliente = new Socket("localhost", 4000);//url y puerto al que se conecta el cliente
            PrintStream envio = new PrintStream(cliente.getOutputStream());//ecribe el flijo de salida
            Scanner teclado = new Scanner(System.in);//recupera lo que se ingresa mediante el teclado
            System.out.println("Ingresa la ruta del archivo a enviar: ");
            String ruta = teclado.nextLine();
            FileInputStream origen = new FileInputStream(ruta);//archivo a enviar
            byte[] buffer = new byte[1024];
            int len;
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();
            cliente.close();
        } catch (IOException ex) {
            ex.printStackTrace();
           
        }
    }
}
