package comunicaciones;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServerFile {

    public static void main(String[] args) {
        try {
            ServerSocket servidor = new ServerSocket(4000);//puerto
            Scanner teclado = new Scanner(System.in);
            System.out.println("Ingresa el destino(path)");//destino donde se van a guardar los archivos
            String path = teclado.nextLine();
            Socket cliente = servidor.accept();
            InputStream llegada = cliente.getInputStream();
            FileOutputStream dcestino = new FileOutputStream(path);//crea un archivo,resive ruta y nombre del archico con su extención
            byte[] buffer = new byte[1024];
            int len;
            while ((len = llegada.read(buffer)) > 0) {
                dcestino.write(buffer, 0, len);
            }
            dcestino.close();
            cliente.close();
        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}
