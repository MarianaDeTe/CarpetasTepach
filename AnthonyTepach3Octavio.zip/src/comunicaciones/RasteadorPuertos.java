package comunicaciones;


import java.net.Socket;


/**
 *
 * @author AnthonyTepach
 */
public class RasteadorPuertos {
//65353 puertos logicos 
    public static void main(String[] args) {
        Socket rastreador;//cliente
        for (int i = 3300; i < 3310; i++) {
            try {
                rastreador = new Socket("10.11.4.117", i);//url y puerto
                System.out.println("Puerto abierto: " + i);
            } catch (Exception ex) {
                System.out.println("puerto cerrado: " + i);
            }
        }
    }
}
