/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author AnthonyTepach
  * esto ayuda a saber si los puertos estan abiertos y si son vulnerables
 */
public class RastreadorPuertos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Socket rastreador;//creacion de instancia
        for (int i = 3300; i < 3310; i++) {
            try{/**
             * intenta crear una conexion, utilizando un constructor
             */
               rastreador = new Socket("localhost",i);//recibe la url o una ip
               rastreador = new Socket("10.11.4.105",i);
                System.out.println("Puerto abierto: " + i);
            }catch(Exception e){
                System.out.println("Puerto cerrado: " + i + e);
            }
        }
    }
    
}
