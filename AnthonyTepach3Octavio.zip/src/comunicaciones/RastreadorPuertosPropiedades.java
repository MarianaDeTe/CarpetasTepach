/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.net.Socket;

/**
 *
 * @author AnthonyTepach
 */
public class RastreadorPuertosPropiedades extends Thread {

    Socket rastreador;//creacion de instancia
    private String url;
    int i;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
   
    public void run() {
        for (i = 3300; i < 3310; i++) {
            try {
                rastreador = new Socket(getUrl(), i);
                System.out.println("Puerto abierto: " + i);

            } catch (Exception e) {
                System.out.println("Puerto cerrado: " + i + e);
            }
        }
    }
}
