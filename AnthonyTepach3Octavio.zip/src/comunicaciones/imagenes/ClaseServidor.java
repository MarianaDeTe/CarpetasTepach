package comunicaciones.imagenes;

import java.io.DataInputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

public class ClaseServidor implements Runnable {

    String archivo;

    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public void iniciaServicio() {

        try {
            ServerSocket servidor = new ServerSocket(5000);
            Socket cliente2 = servidor.accept();
            DataInputStream di = new DataInputStream(cliente2.getInputStream());
            setArchivo(di.readUTF());
            di.close();

            Socket cliente = servidor.accept();
            InputStream llegada = cliente.getInputStream();
            FileOutputStream destino = new FileOutputStream("C:\\Users\\Alumnos\\Desktop\\ImagenesRecibidos\\" + getArchivo());
            byte[] buffer = new byte[1024];
            int len;
            while ((len = llegada.read(buffer)) > 0) {
                destino.write(buffer, 0, len);
            }
            JOptionPane.showMessageDialog(null, "Trasferencia exitosa");
            destino.close();
            cliente.close();
            cliente2.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void run() {
        iniciaServicio();
    }
}
