/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones.imagenes;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;

/**
 *
 * @author Alumnos
 */
public class ClaseCliente {

    String ruta;

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public void cliente(String ruta) {
        try {
            Socket cliente2 = new Socket("localhost", 5000);//url y oueto al que se conecta el cliente
            File ima = new File(ruta);
            DataOutputStream dt = new DataOutputStream(cliente2.getOutputStream());//flujo nde salida
            dt.writeUTF(ima.getName());
            dt.close();
            cliente2.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            Socket cliente = new Socket("localhost", 5000);
            PrintStream envio = new PrintStream(cliente.getOutputStream());//ecribe el flijo de salida
            FileInputStream origen = new FileInputStream(getRuta());
            byte[] buffer = new byte[1024];
            int len;
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();
            cliente.close();
        } catch (Exception ex) {
            ex.printStackTrace();

        }

    }

}
