package comunicaciones;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import java.net.Socket;


/**
 *
 * @author Alumnos
 */
public class ClientePDF {

    String nombre, parrafo;

    public String getParrafo() {
        return parrafo;
    }

    public void setParrafo(String parrafo) {
        this.parrafo = parrafo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void cliente() {
        try {
            Socket cliente = new Socket("10.11.4.117", 4000);//ip y puerto al que se va a conectar
            PrintStream envio = new PrintStream(cliente.getOutputStream());//ecribe el flijo de salida
           
            FileInputStream origen = new FileInputStream("G:\\UTTEC\\Desarrollo de Aplicaciones II\\4TIC1BryanAnthonyTepachReyes\\" + getNombre() + ".pdf");
            byte[] buffer = new byte[1024];
            int len;
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();
            cliente.close();
        } catch (IOException ex) {
            ex.printStackTrace();

        }
    }
  

    public void creaPDF() {
        try {
            Paragraph parrafo = new Paragraph();
            Font fuente = new Font();
            fuente.setColor(255, 100, 96);
            fuente.setSize(50);

//            parrafo.setFont(new Font(Font.FontFamily.HELVETICA, 40, Font.BOLD));//cambia el tamnaño y tipo de fuente
            parrafo.setFont(fuente);
            parrafo.add(getNombre() + "\n");//se le agrega el contenido al parradp

            Document doc = new Document(PageSize.LETTER);//se crea el documento y el tamaño que va a tener
            PdfWriter.getInstance(doc, new FileOutputStream(getNombre() + ".pdf"));
            doc.open();//
            parrafo.setAlignment(Element.ALIGN_CENTER);//alienea el parrafo al centro
            doc.add(parrafo);
            doc.add(new Paragraph(getParrafo()));

            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
