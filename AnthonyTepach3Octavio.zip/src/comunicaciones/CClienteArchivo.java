/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Alumnos
 */
public class CClienteArchivo implements Runnable {

    String arch;

    public String getArch() {
        return arch;
    }

    public void setArch(String arch) {
        this.arch = arch;
    }

    @Override
    public void run() {
        solicita();
    }

    /**
     * método que envia un archivo mediante FileInputStream al un ServerSocket
     */
    public void solicita() {
        try {
            Socket cliente = new Socket("localhost", 4000);//ip Y puerto a conectarce *nota: tiene que ser el mismo puerto conel que inicia el servidor
            PrintStream envio = new PrintStream(cliente.getOutputStream());//ecribe el flijo de salida
            FileInputStream origen = new FileInputStream("C:\\Users\\Alumnos\\Downloads\\ArchivosServidor\\" + getArch());//archivo a enviar
            byte[] buffer = new byte[1024];//arreglo que envia byte a byte
            int len;
            while ((len = origen.read(buffer)) > 0) {
                envio.write(buffer, 0, len);
            }
            envio.close();//cietra el envio 
            cliente.close();//cierra el cliente
        } catch (IOException ex) {
            ex.printStackTrace();

        }

    }

}
