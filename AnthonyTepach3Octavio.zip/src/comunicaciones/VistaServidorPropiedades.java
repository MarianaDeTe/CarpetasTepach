/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author AnthonyTepach
 */
public class VistaServidorPropiedades extends Thread{
    
    private String mensaje;

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    @Override
    public void run() {
        VistaClientePropiedades vc = new VistaClientePropiedades();
        try {
            ServerSocket servidor = new ServerSocket(vc.getPuerto());
            System.out.println("Escucha en el puerto: " + servidor.getLocalPort());
            DataOutputStream dt;
            for (int i = 0; i <= 3; i++) {//espera recibir la solicitud
                Socket sc = servidor.accept();
                dt = new DataOutputStream(sc.getOutputStream());//flujo de salida = socket
                System.out.println("sirvo al cliente: " + i);//impresion del servidor
                dt.writeUTF(getMensaje() + i);
                dt.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
