/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.DataInputStream;
import java.net.Socket;

/**
 *
 * @author Alumnos
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            Socket cliente = new Socket("localhost",5000);//urel y pueto al que se conecta el cliente
            DataInputStream di = new DataInputStream(cliente.getInputStream());//flujo de entrada
            System.out.println(di.readUTF());//inprime lo que recibe
            di.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
