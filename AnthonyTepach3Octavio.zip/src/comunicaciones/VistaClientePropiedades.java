/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.DataInputStream;
import java.net.Socket;

/**
 *
 * @author Alumnos
 */
public class VistaClientePropiedades extends Thread{
    String url, recMensaje;
    private int puerto;

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * @return the puerto
     */
    public int getPuerto() {
        return puerto;
    }

    /**
     * @param puerto the puerto to set
     */
    public void setPuerto(int puerto) {
        this.puerto = puerto;
    }
    
    /**
     * @return the recMensaje
     */
    public String getRecMensaje() {
        return recMensaje;
    }

    /**
     * @param recMensaje the recMensaje to set
     */
    public void setRecMensaje(String recMensaje) {
        this.recMensaje = recMensaje;
    }
    
    @Override
    public void run(){
        try{
            Socket cliente = new Socket(getUrl(),getPuerto());
            DataInputStream di = new DataInputStream(cliente.getInputStream());
            setRecMensaje(di.readUTF());
            di.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
