/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;


/**
 *
 * @author Alumnos
 */
public class CServidorArchivo{
String archivo;
 CClienteArchivo cc = new CClienteArchivo();
    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }
   
   public void inicia(String archivo){
      try {
            ServerSocket servidor = new ServerSocket(4000);//puerto
            Socket cliente = servidor.accept();//acepta la peticion del cliente
            InputStream llegada = cliente.getInputStream();//recupera el fluejo de datos que entran
           
            FileOutputStream dcestino = new FileOutputStream("C:\\Users\\Alumnos\\Desktop\\ArchivosRecibidos//"+archivo);//crea un archivo,resive ruta y nombre del archico con su extención
            byte[] buffer = new byte[1024];
            int len;
            while ((len = llegada.read(buffer)) > 0) {
                dcestino.write(buffer, 0, len);
            }
            dcestino.close();
            cliente.close();
        } catch (IOException e) {
            e.printStackTrace();

        }
   }
}
