/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.net.Socket;

/**
 *
 * @author AnthonyTepach
 */
public class C17_03 extends Thread {//clase que extiende de la clase Thread(hilo)
/**
 * vaisables Strinc con sus respectivos get y set
 */
    String url, abierto;

    public String getAbierto() {
        return abierto;
    }

    public void setAbierto(String abierto) {
        this.abierto = abierto;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    /**
     * Método abtracto de la clase Thread el cual es el metrod principal que ejecuta el hilo
     */
    @Override
    public void run() {
        
        //manda a llamar al método busca
        busca();
    }

    private void busca() {
        Socket r;//se declara cliente
        for (int i = 3300; i < 3310; i++) {
            try {
                // la i del for actua como los puertos a loa que se quiere conectar
                r = new Socket(getUrl(), i);//se le asigna una url y puerto

                if (r.isConnected()) {
                    String d = "Puerto abierto: " + i;
                    d = d + "\n";
                    setAbierto(d);
                }

            } catch (Exception ex) {
                String a=("cerrado: " + i);
                System.out.println(a);

            }
        }
    }

}
