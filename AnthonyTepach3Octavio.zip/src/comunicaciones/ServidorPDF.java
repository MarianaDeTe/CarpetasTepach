/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicaciones;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Alumnos
 */
public class ServidorPDF {

    String archivo;

    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public void inicia() {
        try {
            ServerSocket servidor = new ServerSocket(4000);//puerto
            Scanner teclado = new Scanner(System.in);
            archivo=JOptionPane.showInputDialog(null,"Nombre del archivo a recibir");

            String path = "C:\\Users\\Alumnos\\Desktop\\recibePDF\\" + getArchivo() + ".pdf";//destino del archvo
            Socket cliente = servidor.accept();
            InputStream llegada = cliente.getInputStream();
            FileOutputStream dcestino = new FileOutputStream(path);//crea un archivo,resive ruta y nombre del archico con su extención
            byte[] buffer = new byte[1024];
            int len;
            while ((len = llegada.read(buffer)) > 0) {
                dcestino.write(buffer, 0, len);
            }
            dcestino.close();
            cliente.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(e.getStackTrace());

        }

    }

  
}
