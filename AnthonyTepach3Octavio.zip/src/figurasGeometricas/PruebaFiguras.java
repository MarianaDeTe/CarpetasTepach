/**
 * AUTOR: AnthonyTepach.
 */
package figurasGeometricas;

public class PruebaFiguras {

    public static void main(String[] args) {
        Figura cu = new Cuadrado();
        Triangulo tri = new Triangulo();
        cu.setValorLado(5);
        System.out.println("El área del cuadrado es:"+cu.obtenerArea());
        tri.setValorLado(5);
        System.out.println("El área del triangulo es: "+tri.obtenerArea());
        
    }
}
