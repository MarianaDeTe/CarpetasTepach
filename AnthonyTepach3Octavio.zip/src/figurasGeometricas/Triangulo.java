/**
 * AUTOR: AnthonyTepach.
 */
package figurasGeometricas;

/**
 * clase que hereda de Figura,se implementan los métodos que no se implementaron
 * en la clase abstracta
 */
public class Triangulo extends Figura {

    public Triangulo() {

    }

    public Triangulo(double lado) {
        setValorLado(lado);
    }

    /**
     * método sobre escrito que obtiene el area del triangulo
     *
     * @return
     */
    @Override
    public double obtenerArea() {
        setArea((getValorLado() * getValorLado()) / 2);
        return getArea();
    }

    /**
     * método sobre escrito que obtiene el perimetro del triangulo
     *
     * @return
     */
    @Override
    public double obtenerPerimetro() {
        setPerimetro(getValorLado() * 3);
        return getPerimetro();
    }
}
