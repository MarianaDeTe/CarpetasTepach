package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.Statement;

public class ReportePDF {
    
    public static void main(String[] args) {
        
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Reporte.pdf"));
            doc.open();
            Conexion objConexion = new Conexion();
            Statement sentencia = objConexion.obtenerConexion().createStatement();
            String sql = "SELECT * FROM PERSONA";
            ResultSet resul = sentencia.executeQuery(sql);
                       
            PdfPTable mitabla = new PdfPTable(4);// en el constructor mandas el numero de columnas 
            mitabla.addCell("Nombre");
            while (resul.next()) {                
                doc.add(new Phrase(resul.getString(2).concat(" ")));
                doc.add(new Phrase(resul.getString(3).concat("\n")));
            }
            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
