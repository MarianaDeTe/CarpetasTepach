package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class MiPrimerPDF {

    public static void main(String[] args) {
        try {
            Document doc = new Document(PageSize.LETTER);//objeto itxt//pasa el tamaño de la hoja
            PdfWriter.getInstance(doc, new FileOutputStream("primer.pdf"));//manda archivo en memoria y lo crea fisio ,file resive el nombre del pdf
            doc.open();//
            doc.add(new Paragraph("hola mundo"));//crear parafos
            doc.add(new Paragraph("Anthony Tepach"));//instancia anonima solo se puede modificar una vez
            doc.close();//termina de usarlo
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
