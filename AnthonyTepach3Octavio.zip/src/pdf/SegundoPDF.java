package pdf;

import com.itextpdf.text.Document;

import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class SegundoPDF {

    public static void main(String[] args) {
        try {
            Rectangle dimen = new Rectangle(400f, 150f);//permite dar los tamaños diseñados por nosotros
            Document docu = new Document(dimen, 10, 10, 20, 30);//se le envia el tamaño de la hoja se le le asigna los margenes
            PdfWriter.getInstance(docu, new FileOutputStream("segundo.pdf"));
            docu.open();
            for (int i = 0; i <= 10; i++) {
                docu.add(new Paragraph("párrafo " + i));
            }
            docu.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
