/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import conexiones.Conexion;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.ResultSet;

import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alumnos
 */
public class generaCredencial {

    private String Nombre, curp, apat, amat;
    private int Id;

    public void generaReporte() {
        try {
            Conexion objConexion = new Conexion();
            Statement sentencia = objConexion.obtenerConexion().createStatement();
            String sql = "SELECT * FROM PERSONA WHERE PERSONAID=" + getId();
            ResultSet resul = sentencia.executeQuery(sql);
            while (resul.next()) {
                setNombre(resul.getString(2));
                setApat(resul.getString(3));
                setAmat(resul.getString(4));
                setCurp(resul.getString(5));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void credencialPDF() {
        System.out.println(getNombre());
        try {

            Rectangle dimen = new Rectangle(270f, 150f);
            Document doc = new Document(dimen, 10, 10, 20, 30);
            PdfWriter.getInstance(doc, new FileOutputStream("Credencial.pdf"));
            Paragraph parrafo = new Paragraph();
            Paragraph datos = new Paragraph();
             Paragraph Vigencia = new Paragraph();
            Font fuente = new Font();
            fuente.setSize(15);
            Font fuente2 = new Font();
            fuente2.setSize(5);
            datos.setAlignment(Element.ALIGN_CENTER);
            parrafo.setAlignment(Element.ALIGN_CENTER);
            Vigencia.setAlignment(Element.ALIGN_RIGHT);
            Vigencia.setAlignment(Element.ALIGN_BASELINE);
            
            parrafo.setFont(fuente);
            datos.setFont(fuente2);
            parrafo.add("Universidad 'X'");
            datos.add("Nombre: " + getNombre() + "\nApellido Paterno: " + getApat());
            Vigencia.add("Vicencia 2016");
            doc.open();
            Image imgDos = Image.getInstance("Koala.jpg");
            imgDos.scalePercent(5);
            imgDos.setAbsolutePosition(10, 95);
            doc.add(imgDos);
            doc.add(parrafo);
            doc.add(datos);

            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the curp
     */
    public String getCurp() {
        return curp;
    }

    /**
     * @param curp the curp to set
     */
    public void setCurp(String curp) {
        this.curp = curp;
    }

    /**
     * @return the apat
     */
    public String getApat() {
        return apat;
    }

    /**
     * @param apat the apat to set
     */
    public void setApat(String apat) {
        this.apat = apat;
    }

    /**
     * @return the amat
     */
    public String getAmat() {
        return amat;
    }

    /**
     * @param amat the amat to set
     */
    public void setAmat(String amat) {
        this.amat = amat;
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }

    /**
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }
}
