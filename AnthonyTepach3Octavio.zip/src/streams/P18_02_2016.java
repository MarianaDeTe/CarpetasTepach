package streams;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

public class P18_02_2016 {

    public void binario( String Mensaje) {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("numeros.dat"));
            arcSalida.writeUTF(Mensaje);
            arcSalida.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
                    }
    }

    public void pdf( String Mensaje) {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("numeros.pdf"));
            doc.open();//
            doc.add(new Paragraph(Mensaje));
            doc.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void texto(String Mensaje) {
        try {
            FileWriter archivo = new FileWriter("numeros.txt");
            archivo.write(Mensaje);
            archivo.close();
        } catch (Exception e) {
             System.err.println(e.getMessage());
        }
    }
    
}
