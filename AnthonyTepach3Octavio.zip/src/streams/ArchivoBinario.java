package streams;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
/**
 * 
 * @author Anthony Tepach 4TiC1
 */
public class ArchivoBinario {
    
    

    public static void main(String[] args) {
        try {
            DataOutputStream arcSalida=new DataOutputStream(new FileOutputStream("arc.dat"));//creacion de archivos binarios
            arcSalida.writeInt(135);//escribe un numero entero
            arcSalida.writeDouble(48.658);//escribe un número Double
            arcSalida.writeUTF("Tepach");//escribe un String
            arcSalida.close();
            
            DataInputStream arcLector = new DataInputStream(new FileInputStream("arc.dat"));//lee un archivo
            int i=arcLector.readInt();//lee un número entero
            double d=arcLector.readDouble();//lee un número Double
            String s=arcLector.readUTF();//lee un String
            System.out.println("INT "+i+" DOUBLE "+d+" STRING "+s);// imprime lo que se lee del documento
            arcLector.close();
                
        } catch (Exception e) {

        }
    }
}
