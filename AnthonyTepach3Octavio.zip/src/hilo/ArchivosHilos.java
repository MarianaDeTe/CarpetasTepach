/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import javax.swing.JOptionPane;
import javax.swing.plaf.RootPaneUI;

/**
 *
 * @author DIN
 */
public class ArchivosHilos extends Thread {

    String tipo, mensaje;

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public void run() {
        if (getTipo().equalsIgnoreCase("Binario")) {
            binario();
        } else if (getTipo().equalsIgnoreCase("Texto")) {
            texto();
        } else if (getTipo().equalsIgnoreCase("PDF")) {
            pdf();
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona un tipo de archivo");
        }

    }

    public void binario() {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("hilo.dat"));
            arcSalida.writeUTF(getMensaje());
            arcSalida.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void texto() {
        try {
            FileWriter archivo = new FileWriter("hilo.txt");
            archivo.write(getMensaje());
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void pdf() {
       try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("hillo.pdf"));
            doc.open();//
            doc.add(new Paragraph(getMensaje()));
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
