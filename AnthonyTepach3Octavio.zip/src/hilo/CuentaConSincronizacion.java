/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;


import java.util.concurrent.*;
import java.util.concurrent.locks.*;



/**
 *
 * @author Alumnos
 */
public class CuentaConSincronizacion {

    public static final Cuenta monto = new Cuenta();

    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool();
        for (int i = 0; i < 100; i++) {
            executor.execute(new AgregarCentavo());
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
        }
        System.out.println("Cual es el Balance ? " + monto.getBalance());

    }

    private static class AgregarCentavo implements Runnable {

        @Override
        public void run() {
            monto.depositar(1);
        }
    }

    private static class Cuenta {

        private static final Lock lock = new ReentrantLock();
        int balance = 0;

        public int getBalance() {
            return balance;
        }

        public synchronized void depositar(int i) {
            lock.lock();
            try {
                int newBalance = balance + i;
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    balance = newBalance;
                }
            } finally {
                lock.unlock();
            }
        }
    }
}
