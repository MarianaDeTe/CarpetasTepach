/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import com.itextpdf.text.Document;

import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;


/**
 *
 * @author Alumnos
 */
public class BigPdf {

    public void generarPDF() {
        try {

            Document doc = new Document(PageSize.LETTER);//se crea el documento y el tamaño que va a tener
            PdfWriter.getInstance(doc, new FileOutputStream("ConSinHilo.pdf"));
            doc.open();
            for (int i = 0; i <= 90000000; i++) {
                Paragraph parrafo2 = new Paragraph("Párrafo  n° " + i);
                doc.add(parrafo2);
            }
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
