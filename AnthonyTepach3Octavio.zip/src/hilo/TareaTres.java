/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.io.DataOutputStream;
import java.io.FileOutputStream;

/**
 *
 * @author Alumnos
 */
public class TareaTres implements Runnable {

    @Override
    public void run() {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("arc.dat"));
            arcSalida.writeInt(135);
            arcSalida.writeDouble(48.658);
            arcSalida.writeUTF("Tepach");
            arcSalida.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
