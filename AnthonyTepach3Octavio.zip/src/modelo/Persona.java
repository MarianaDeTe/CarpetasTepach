/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import conexiones.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Anthony Tepach
 */
public class Persona {

    private int personaID;
    private String nombre, paterno, materno, curp;

    public Persona() {

    }

    public Persona(String nom) {
        nombre = nom;
    }

    public Persona(int x) {
        personaID = x;

        obtenerPersona();
    }

    /**
     * @return the personaID
     */
    public int getPersonaID() {
        return personaID;
    }

    /**
     * @param personaID the personaID to set
     */
    public void setPersonaID(int personaID) {
        this.personaID = personaID;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the paterno
     */
    public String getPaterno() {
        return paterno;
    }

    /**
     * @param paterno the paterno to set
     */
    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    /**
     * @return the materno
     */
    public String getMaterno() {
        return materno;
    }

    /**
     * @param materno the materno to set
     */
    public void setMaterno(String materno) {
        this.materno = materno;
    }

    /**
     * @return the curp
     */
    public String getCurp() {
        return curp;
    }

    /**
     * @param curp the curp to set
     */
    public void setCurp(String curp) {
        this.curp = curp;
    }

    /**
     * consulta de una persona, pero como el código SQL esta mezclado con el
     * código JAVA
     *
     * @return
     */
    public boolean obtenerPersona() {
        try {
            Conexion objConexion = new Conexion();
            String sql = "SELECT * FROM persona WHERE personaID=" + personaID;
            Statement sentencia = objConexion.obtenerConexion().createStatement();
            ResultSet registro = sentencia.executeQuery(sql);
            while (registro.next()) {
                nombre = registro.getString(2);
                paterno = registro.getString(3);
                materno = registro.getString(4);
                curp = registro.getString(5);
            }
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "no se encuentra en la base");
            e.printStackTrace();
        }
        return false;
    }

    /**
     *
     * @param xpersona
     * @return
     */
    public boolean getPersonaByPreparedStatement(int xpersona) {

        try {
            String sql = "select * from persona where personaid=?";
            Conexion objConexion = new Conexion();
            PreparedStatement ps = objConexion.obtenerConexion().prepareStatement(sql);
            ps.setInt(1, xpersona);
            ResultSet registro = ps.executeQuery();
            while (registro.next()) {
                personaID = registro.getInt(1);
                nombre = registro.getString(2);
                paterno = registro.getString(3);
                materno = registro.getString(4);
                curp = registro.getString(5);
            }
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }

    /**
     *
     * @param id
     * @return
     */
    public boolean eliminarPreparedSatatement(int id) {
        try {
            String sql = "delete from persona where personaid=?";
            Conexion objConexion = new Conexion();
            PreparedStatement ps = objConexion.obtenerConexion().prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return false;

    }

    /**
     *
     * @param xpersona
     * @return
     */
    public boolean buscarPersonaByCallable(int xpersona) {
        try {
            Conexion objConexion = new Conexion();
            CallableStatement cs = objConexion.obtenerConexion().prepareCall("{call buscar(?)}");
            cs.setInt(1, xpersona);
            ResultSet registro = cs.executeQuery();
            while (registro.next()) {
                personaID = registro.getInt(1);
                nombre = registro.getString(2);
                paterno = registro.getString(3);
                materno = registro.getString(4);
                curp = registro.getString(5);
            }
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }

    public boolean eliminarPersonaByCallable(int xpersona) {
        try {
            Conexion objConexion = new Conexion();
            CallableStatement cs = objConexion.obtenerConexion().prepareCall("{call eliminar(?)}");
            cs.setInt(1, xpersona);
            cs.executeQuery();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }

    public boolean agregarPersonaByCallable(int i, String nomb, String pat, String mat, String curp) {
        try {
            Conexion objConexion = new Conexion();
            CallableStatement cs = objConexion.obtenerConexion().prepareCall("{call insertar(?,?,?,?,?)}");
            cs.setInt(1, i);
            cs.setString(2, nomb);
            cs.setString(3, pat);
            cs.setString(4, mat);
            cs.setString(5, curp);
            cs.executeQuery();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Método que devuelve un valor de tipo booleano, resive 5 parametros y
     * manda a llamar un procedimiento almacenado en la base de datos
     *
     * @param i
     * @param nomb
     * @param pat
     * @param mat
     * @param curp
     * @return
     */
    public boolean modificarPersonaByCallable(int i, String nomb, String pat, String mat, String curp) {
        try {
            Conexion objConexion = new Conexion();
            CallableStatement cs = objConexion.obtenerConexion().prepareCall("{call actualizar(?,?,?,?,?)}");
            cs.setInt(1, i);
            cs.setString(2, nomb);
            cs.setString(3, pat);
            cs.setString(4, mat);
            cs.setString(5, curp);
            cs.executeQuery();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public ResultSet consulta() {
        ResultSet registro = null;
        try {
            Conexion objConexion = new Conexion();
            CallableStatement cs = objConexion.obtenerConexion().prepareCall("{call reporte()}");
            cs.executeQuery();
            registro = cs.getResultSet();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return registro;

    }

    public void llenaTabla() {
        try {
//            DefaultTableModel tabla = (DefaultTableModel) jTable1.getModel();
            ResultSet datos = consulta();
            int fila = 0;
            while (datos.next()) {
//                tabla.addRow(new Object[]{"", "", ""});
//                tabla.setValueAt(datos.getString(1), fila, 0);
//                tabla.setValueAt(datos.getString(3), fila, 1);
                fila++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Persona.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void hola() {
        try {
            ResultSet j = consulta();
            while (j.next()) {
//                JTextField1.setText(j.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Persona.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
