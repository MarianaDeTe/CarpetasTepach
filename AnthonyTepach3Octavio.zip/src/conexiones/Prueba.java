package conexiones;

import java.sql.SQLException;
/**
 * clase donde e prueba si funciona la clase conexion
 * @author anthonytepach
 */
public class Prueba {

    public static void main(String[] args) throws SQLException {
        Conexion obj = new Conexion();
        obj.obtenerConexion();
//        obj.setUser("root");
        System.out.println(obj.obtenerConexion().getCatalog());
    }

}
