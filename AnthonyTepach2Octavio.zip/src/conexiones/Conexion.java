package conexiones;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author AnthonyTepach
 */
public class Conexion {

    private String url, user, passwd;
    private Connection objConexion;

    public Conexion() {
        url = "jdbc:mysql://localhost/uttec";
        user = "root";
        passwd = "";
//        passwd = "Tbryan.96";
    }

    /**
     * método de tipo 'Connection' busca la clase Driver dentro de la libreria
     * com.mysql.jdbc, le envia los parametros 'url', 'user' y 'passwd' para
     * hacer la conexcion con nuestro gestor de base de datos
     *
     * @return
     */
    public Connection obtenerConexion() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            setObjConexion(DriverManager.getConnection(getUrl(), getUser(), getPasswd()));
            return getObjConexion();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return getObjConexion();
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(String user) {
//        if (user.equals("root")) {
//            this.user = "no valido";
//        } else {
        this.user = user;
//        }
    }

    /**
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /**
     * @param passwd the passwd to set
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /**
     * @return the objConexion
     */
    public Connection getObjConexion() {
        return objConexion;
    }

    /**
     * @param objConexion the objConexion to set
     */
    public void setObjConexion(Connection objConexion) {
        this.objConexion = objConexion;
    }
    /**
     *
     */
}
