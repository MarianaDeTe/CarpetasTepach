/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.FileReader;

/**
 *
 * @author Alumnos
 */
public class LeerGrafico {

    private String msj;

    public void leer(String arch) {
        /**
         * lee el contenido de un archivo
         */
        try {
            FileReader leer = new FileReader(arch);
            int caracter = leer.read();
            while (caracter != -1) {
                if (msj == null) {
                    msj = "";
                }
                msj = msj + String.valueOf((char) caracter);
                caracter = leer.read();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getMsj() {
        return msj;
    }

    public void setMsj(String msj) {
        this.msj = msj;
    }
}
