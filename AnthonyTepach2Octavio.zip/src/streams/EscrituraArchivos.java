/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.FileWriter;

/**
 *
 * @author AnthonyTepach
 */
public class EscrituraArchivos {

    public static void main(String[] args) {
        try {
            //recibe el nombre del archivo en donde se quuiere escribir 
            //más aparte un valor bolean que permite escribir sin sustituir el texto anterior 
            FileWriter archivo = new FileWriter("archivo.txt", true);
            archivo.write(" 123 ");
            archivo.write(49);
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
