package streams;

import java.io.File;

/**
 *
 * @author Tepach
 */

public class CaseFilePractica {
    private String ruta;
    private boolean arc,directorio,lectura,escritura,ejecucion,oculto,existe;
    /**
     *recibe como parametro un String el cual es la ruta del archivo
     * @param archi 
     */
    public void recuperaPropiedade(String archi){
        File archivo = new File(archi);
        setRuta(archivo.getAbsolutePath());//recupera la ruta absoluta del archivo
        setArchivo(archivo.isFile());//verifica si es archivo
        setDirectorio(archivo.isDirectory());//verifica si es directorio(carpeta)
        setLectura(archivo.canRead());//verifica si se puede leer
        setEjecucion(archivo.canExecute());//verifica si se puede executar
        setEscritura(archivo.canWrite());//verifica si se puede escribir
        setOculto(archivo.isHidden());//verifica si esta oculto
        setExiste(archivo.exists());//verifica si existe el archivo o directorio
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public boolean getArchivo() {
        
        return arc;
    }

    public void setArchivo(boolean archivo) {
        this.arc = archivo;
    }

    public boolean esDirectorio() {
        return directorio;
    }

    public void setDirectorio(boolean directorio) {
        this.directorio = directorio;
    }

    public boolean esLectura() {
        return lectura;
    }

    public void setLectura(boolean lectura) {
        this.lectura = lectura;
    }

    public boolean esEscritura() {
        return escritura;
    }

    public void setEscritura(boolean escritura) {
        this.escritura = escritura;
    }

    public boolean esEjecucion() {
        return ejecucion;
    }

    public void setEjecucion(boolean ejecucion) {
        this.ejecucion = ejecucion;
    }

    public boolean esOculto() {
        return oculto;
    }

    public void setOculto(boolean oculto) {
        this.oculto = oculto;
    }

    public boolean isExiste() {
        return existe;
    }

    public void setExiste(boolean existe) {
        this.existe = existe;
    }
}
