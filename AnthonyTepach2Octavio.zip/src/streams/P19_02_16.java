/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.Arrays;

/**
 *
 * @author Alumnos
 */
public class P19_02_16 {

    private String listado = "";

    public void archivo(String ruta) {
        File arch = new File(ruta);
        File[] lis = arch.listFiles();
        String a[] = new String[lis.length];
        for (int x = 0; x < lis.length; x++) {
            a[x] = lis[x].getName().concat(lis[x].isFile() ? "   Archivo" : "   Directorio");
            listado = listado + a[x] + " \n";
        }

    }

    public void binario() {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream("archivos.dat"));
            arcSalida.writeUTF(listado);
            arcSalida.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void pdf() {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("archivos.pdf"));
            doc.open();//
            doc.add(new Paragraph(listado));
            doc.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void texto() {
        try {
            FileWriter archivo = new FileWriter("archivos.txt");
            archivo.write(listado);
            archivo.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

}
