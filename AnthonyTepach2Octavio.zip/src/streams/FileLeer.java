/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package streams;

import java.io.FileReader;

/**
 *
 * @author Tepach
 */
public class FileLeer {

    public static void main(String[] args) {
        /**
         * lee el contenido de un archivo de texto
         */
        try {
            FileReader archivo = new FileReader("C:\\Users\\Alumnos\\Desktop/archivo.txt");
            int valor = archivo.read();
            while (valor != -1) {//
                System.out.print((char) valor);
                valor = archivo.read();
            }
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
