package streams;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

/**
 *
 * @author Alumnos
 */
public class PracticaArchivos_1702 {

    public void binario(String nombre, String Mensaje) {
        try {
            DataOutputStream arcSalida = new DataOutputStream(new FileOutputStream(nombre + ".dat"));
            arcSalida.writeUTF(Mensaje);
            arcSalida.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void pdf(String nombre, String Mensaje) {
        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream(nombre + ".pdf"));
            doc.open();//
            doc.add(new Paragraph(Mensaje));
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void texto(String nombre, String Mensaje) {
        try {
            FileWriter archivo = new FileWriter(nombre + ".txt");
            archivo.write(Mensaje);
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
