package streams;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author AnthonyTepach
 */
public class ClaseFile {

    public static void main(String[] args) throws IOException {
        File archivo = new File("archivo.txt");
        
        System.out.println(archivo.isFile() ? "es un archivo" : "no es un archivo");//pregunta si el objeto creado es un archivo
        System.out.println(archivo.isDirectory()?"es un directorio":"no es un directorio");//pregunta si el objeto creado es un directorio
        System.out.println(archivo.canRead()?"Se puede leer":"No se puede leer");
        System.out.println(archivo.canWrite()?"Se puede Escribir":"No se puede Escribir");
        System.out.println(archivo.exists()?"Si existe el archivo":"No existe el archivo");
        System.out.println(archivo.canExecute()?"Si se puede ejecutar":"no se puede ejecutar");
        System.out.println(archivo.mkdir()?"es una carpeta":"No es una carpeta");
        System.out.println(archivo.isHidden()?"Esta oculto el archivo":"no esta oculto el archivo");
        System.out.println(archivo.delete()?"se puede eliminar":"no se puede eliminar");
        System.out.println(archivo.getPath());
        System.out.println("Esta guardado en "+archivo.getAbsolutePath());
        System.out.println(archivo.getCanonicalPath());
        
        System.out.println(archivo.length());
    }
}
