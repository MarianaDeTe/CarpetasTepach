package MVC;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaCirculo extends javax.swing.JPanel implements ActionListener {

    private ModeloCirculo model;

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    public void setModel(ModeloCirculo newModel) {
        model = newModel;
        if (model != null) {
            model.addActionListener(this);
        }
    }

    public ModeloCirculo getModel() {
        return model;
    }

    public void paintComponet(Graphics g) {
        super.paintComponent(g);
        if (model == null)
                return;
        
        g.setColor(model.getColor());
        int xcenter = getWidth() / 2, ycenter = getWidth() / 2;
        int radius = (int) model.getRadius();
        if (model.isFilled()) {
            g.fillOval(xcenter - radius, ycenter - radius, 2 * radius, 2 * radius);
        } else {
            g.drawOval(xcenter - radius, ycenter - radius, 2 * radius, 2 * radius);
        }

    }

}
