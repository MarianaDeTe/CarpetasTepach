package MVC;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class ControladorCirculo extends JPanel {
    
    private ModeloCirculo model;
    private JTextField jtfRadius=new JTextField();
    private JComboBox jcboFilled=new JComboBox(new Boolean[]{new Boolean(false),new Boolean(true)});
    private JButton jbtColor=new JButton("Cambiar color");
    int cambiaColor=0;
    
    public ControladorCirculo(){
        JPanel panel1=new JPanel();
        panel1.setLayout(new GridLayout(2,1));
        panel1.add(new JLabel("Radius"));
        panel1.add(new JLabel("Filled"));
        
        JPanel panel2=new JPanel();
        panel2.setLayout(new GridLayout(3,1));
        panel2.add(jtfRadius);
        panel2.add(jcboFilled);
        panel2.add(jbtColor);
        
        setLayout(new BorderLayout());
        add(panel1,BorderLayout.WEST);
        add(panel2,BorderLayout.CENTER);
        jtfRadius.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(model==null)return;
                    model.setRadius(new Double (jtfRadius.getText()).doubleValue());
                }
            
        });
        
        jcboFilled.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(model==null)return;
                model.setFilled(((Boolean)jcboFilled.getSelectedItem()).booleanValue());
            }
        });
        
        
        jbtColor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambiaColor++;
                if(cambiaColor==1){
                    model.setColor(Color.GREEN);
                }
                else if(cambiaColor==2){
                    model.setColor(Color.RED);
                }
                else if(cambiaColor==3){
                    model.setColor(Color.blue);
                }
                else if(cambiaColor==4){
                    model.setColor(Color.pink);
                }
                else if(cambiaColor==5){
                    model.setColor(Color.yellow);
                }
                else if(cambiaColor==6){
                    model.setColor(Color.MAGENTA);
                }
                else if(cambiaColor==7){
                    model.setColor(Color.ORANGE);
                }
                else if(cambiaColor==8){
                    model.setColor(Color.GRAY);
                }
                else if(cambiaColor==9){
                    model.setColor(Color.CYAN);
                }
            }
        });
        
        
    }
    
    public void setModel(ModeloCirculo newModel){
        model=newModel;
    }
    public ModeloCirculo getModel(){
        return model;
        
    }
    
}
