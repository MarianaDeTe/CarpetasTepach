package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;

import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class TercerPDF {

    public static void main(String[] args) {
        try {
            Paragraph parrafo = new Paragraph();//genera un objeto de tipo pararfo
            Font fuente = new Font(); //objeto de tipo fuente
            fuente.setColor(255, 100, 96);// con esta propiedad se le pueden enviar los colores Rojo,Azul y verde 
            fuente.setSize(50);// se le asigna un tamaño a la fuente
            
//            parrafo.setFont(new Font(Font.FontFamily.HELVETICA, 40, Font.BOLD));//cambia el tamnaño y tipo de fuente
            parrafo.setFont(fuente);
            parrafo.add("Titulo");//se le agrega el contenido al parradp
            Document doc = new Document(PageSize.LETTER);//se crea el documento y el tamaño que va a tener
            PdfWriter.getInstance(doc, new FileOutputStream("tercer.pdf"));
            doc.open();//
            parrafo.setAlignment(Element.ALIGN_CENTER);
            doc.add(parrafo);
            /**
             * for que agrega 20 parrafos y adentro trae un if que alinea a la izquierda a los números impares y a la derecha a los números pares
             */
            for (int i = 1; i <= 2000000; i++) {
                Paragraph parrafo2 = new Paragraph("Párrafo  n° " + i);
                if ((i % 2) == 1) {
                    parrafo2.setAlignment(Element.ALIGN_LEFT);
                } else if ((i % 2 == 0)) {
                    parrafo2.setAlignment(Element.ALIGN_RIGHT);
                }
                doc.add(parrafo2);
//                doc.add(new Paragraph("Párrafo izquierda n° " + i ));
//                Paragraph parrafo3 = new Paragraph("Párrafo derecha n° " + i);
//                parrafo3.setAlignment(Element.ALIGN_RIGHT);
//                doc.add(parrafo3);
            }

            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
