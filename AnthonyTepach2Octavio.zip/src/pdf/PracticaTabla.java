package pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

public class PracticaTabla {

    private int f, c;

    /**
     * constructor sobrecargado que recibe a columna y a fila de la interfaz
     * TablaPDFForm y manda a llamar el método generaTabla()
     *
     * @param colum
     * @param fila
     */
    public PracticaTabla(int colum, int fila) {
        c = colum;
        f = fila;
        generaTabla();
    }

    /**
     * crea el pdf llamado tabla.pdf, en el construnctor de PdfPTable() se le
     * manda el valor de c que es columna, y con un for anidado se llenan las filas y la columnas
     */
    private void generaTabla() {

        try {
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream("Tabla.pdf"));
            doc.open();
            PdfPTable mitabla = new PdfPTable(c);//el constructor recibe el número de columnas
            for (int i = 0; i < f; i++) {
                mitabla.addCell("fila ".concat(String.valueOf(i + 1)));
                for (int j = 1; j < c; j++) {
                    mitabla.addCell("celda ".concat(String.valueOf(i + 2)));
                }
            }
            doc.add(mitabla);
            doc.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
