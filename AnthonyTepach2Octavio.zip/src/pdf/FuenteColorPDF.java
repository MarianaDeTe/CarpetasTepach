/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;

/**
 *
 * @author Alumnos
 */
public class FuenteColorPDF {
    /**
     * m
     * @param titu
     * @param fuTitulo
     * @param Parrafo
     * @param fuParraf 
     */
    public void generarPDFconFuente(String titu, int fuTitulo, String Parrafo, int fuParraf) {
        try {
            Paragraph titulo = new Paragraph();
            Font fuenteTitulo = new Font();
            Paragraph parraf = new Paragraph();
            Font fuenteParraf = new Font();
            fuenteTitulo.setColor(fuParraf, fuParraf, fuTitulo);
            fuenteTitulo.setSize(fuTitulo);
            fuenteParraf.setSize(fuParraf);
            titulo.setFont(fuenteTitulo);
            titulo.add(titu);
            Document doc = new Document(PageSize.LETTER);
            PdfWriter.getInstance(doc, new FileOutputStream(titu + ".pdf"));
            doc.open();//
            titulo.setAlignment(Element.ALIGN_CENTER);
            doc.add(titulo);
            parraf.setFont(fuenteParraf);
            parraf.add(Parrafo);
            doc.add(parraf);
            
            doc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
