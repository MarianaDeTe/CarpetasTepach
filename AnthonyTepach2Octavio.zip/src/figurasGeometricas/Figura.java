package figurasGeometricas;

/**
 * Una clase abstracta no puede instanciarse No se pueden crear objetos de una
 * clase abstracta
 */
/**
 * @author Anthony Tepach.
 */
public abstract class Figura {

    private int ctdLados, ctdAngulos;
    private double area, perimetro, valorLado;
    private String nombre;

    /**
     * clase abstracta declara métodos, pero no se tienen implemendados.
     *
     * @return
     */
    public abstract double obtenerArea();

    public abstract double obtenerPerimetro();

    /**
     * @return the ctdLados
     */
    public int getCtdLados() {
        return ctdLados;
    }

    /**
     * @param ctdLados the ctdLados to set
     */
    public void setCtdLados(int ctdLados) {
        this.ctdLados = ctdLados;
    }

    /**
     * @return the ctdAngulos
     */
    public int getCtdAngulos() {
        return ctdAngulos;
    }

    /**
     * @param ctdAngulos the ctdAngulos to set
     */
    public void setCtdAngulos(int ctdAngulos) {
        this.ctdAngulos = ctdAngulos;
    }

    /**
     * @return the area
     */
    public double getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(double area) {
        this.area = area;
    }

    /**
     * @return the perimetro
     */
    public double getPerimetro() {
        return perimetro;
    }

    /**
     * @param perimetro the perimetro to set
     */
    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the valorLado
     */
    public double getValorLado() {

        return valorLado;
    }

    /**
     * @param valorLado the valorLado to set
     */
    public void setValorLado(double valorLado) {
        this.valorLado = valorLado;
    }

}
