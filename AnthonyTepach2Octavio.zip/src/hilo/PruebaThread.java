/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

/**
 *
 * @author Alumnos
 */
public class PruebaThread {
    public static void main(String[] args) throws InterruptedException {
        ClaseThread hilo1=new ClaseThread();
        ClaseThread hilo2=new ClaseThread();
        ClaseThread hilo3=new ClaseThread();
        hilo1.setName(" uno");
        hilo2.setName(" Dos");
        hilo3.setName(" Tres");
        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo1.sleep(3000);
        hilo2.sleep(3000);
        hilo3.sleep(3000);
        hilo1.join(3000);
        hilo2.join(3000);
        hilo3.join(3000);
    }
}
