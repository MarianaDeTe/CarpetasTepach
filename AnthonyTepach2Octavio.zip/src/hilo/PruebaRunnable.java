/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.util.Scanner;



/**
 *
 * @author Alumnos
 */
public class PruebaRunnable {
    Scanner leer=new Scanner(System.in);
    public static void main(String[] args) {
//         TareaDos obj=new TareaDos();
         TareaTres obj2=new TareaTres();
//          
//         Thread hilo1=new Thread(obj);
//         Thread hilo2=new Thread(obj2);
//                  hilo1.start();
//                  hilo2.start();
                
        
//            obj.numero=5;
//            Thread hilo1=new Thread(obj);
//            TareaUno obj2=new TareaUno();
//            obj2.numero=10;
//            Thread hilo2=new Thread(obj2);
//            hilo1.start();
//            hilo2.start();
//            hilo1.sleep(1000);
//            hilo2.sleep(1000);
    }
}
