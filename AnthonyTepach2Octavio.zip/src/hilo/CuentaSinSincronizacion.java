/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Alumnos
 */
public class CuentaSinSincronizacion {

    public static final Cuenta monto = new Cuenta();

    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool();
        for (int i = 0; i < 100; i++) {
            executor.execute(new AgregarCentavo());
        }
        executor.shutdown();
        System.out.println("Cual es el Balance ? " + monto.getBalance());

    }

    private static class AgregarCentavo implements Runnable {

        @Override
        public void run() {
            monto.depositar(1);
        }
    }

    private static class Cuenta {

        private int balance = 0;

        public int getBalance() {
            return balance;
        }

        public synchronized void depositar(int i) {
            int newBalance = balance + i;
            try {
                Thread.sleep(1);

            } catch (Exception e) {
                e.printStackTrace();
            }
            balance = newBalance;
        }
    }

}
