/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilo;

import java.io.File;


/**
 *
 * @author Alumnos
 */
public class Hilo09_03_16 implements Runnable{

    private String ruta,directorio,archivo;
     int d=0, ar=0;

    



    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    @Override
    public void run() {
        File arch = new File(getRuta());
        File[] a=arch.listFiles();
        for (int i = 0; i < a.length; i++) {
            if (a[i].isFile()) {
                ar++;
                
                setArchivo(String.valueOf(ar));
                System.out.println(getArchivo()+"arch");
                
            }else if(a[i].isDirectory()){
                d++;
                setDirectorio(String.valueOf(d));
                System.out.println(getDirectorio()+"dir");
            }
            
        }
        System.out.println("\n\n\n\n");
    }

    public String getDirectorio() {
        return directorio;
    }

    public void setDirectorio(String directorio) {
        this.directorio = directorio;
    }

    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

}
