package arreglos;

/**
 *
 * @author Anthony
 */
public class MetodoBurbuja {

    /**
     * MÉTODO DE ORDENAMIENTO BURBUJA, es una forma de ordenar un arreglo de
     * menor a mayor, mediante dos cliclos for, el primero de los primeros
     * ciclos es el que hace los recorrido/faces,el segundo for es donde va la
     * comparación,este verifica si el arreglo es menor para poder recorrerlo
     */
    public void burbuja() {
        int A[] = {41, 91, 48, 82, 55, 111, 38, 127, 95, 77, 74};
        int aux;
        for (int k = 0; k < A.length; k++) {
            System.out.print("\t" + A[k]);

        }

        for (int i = 0; i < A.length - 1; i++) {
            for (int j = 0; j < A.length - 1; j++) {
                if (A[j + 1] < A[j]) {
                    aux = A[j + 1];
                    A[j + 1] = A[j];
                    A[j] = aux;

                }

            }
            System.out.println("\n");
            for (int k = 0; k < A.length; k++) {
                System.out.print("\t" + A[k]);

            }

        }
        System.out.println("                        VECTOR FINAL");

    }

    public static void main(String[] args) {
        MetodoBurbuja b = new MetodoBurbuja();
        b.burbuja();

    }
}
