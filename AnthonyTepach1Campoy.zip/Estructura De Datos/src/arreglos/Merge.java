package arreglos;

public class Merge {

    static int arr[] = {4, 3, 2, 1, 0, -1, -2, -3, -4};

    /**
     * método que recibe tres parámetros, recibe a un arreglo de tipo entero el
     * cual se va a definir como pivote, las parámetros izq y der son posiciones
     * del arreglo izq recibe la primera posición del arreglo y der recibe la
     * ultima posición del arreglo.
     *
     * @param A
     * @param izq
     * @param der
     */
    public static void mergesot(int A[], int izq, int der) {

        if (izq < der) {
            int m = (izq + der) / 2;
            System.out.println("Division del a01rreglo "+m);
            mergesot(A, izq, m);
            mergesot(A, m + 1, der);
            merge(A, izq, m, der);
        }

    }

    /**
     * Recibe como parámetros a un arreglo, las posiciones izq y der las cuales
     * son la primera posición y la última respectivamente y a m que es el
     * tamaño del arreglo y despuies lo divide entre dos para ir partiendo el
     * arreglo.
     * @param A
     * @param izq
     * @param m
     * @param der
     */
    public static void merge(int A[], int izq, int m, int der) {

        int i, j, k;
        int[] B = new int[A.length]; //array auxiliar
        for (i = izq; i <= der; i++) //copia ambas mitades en el array auxiliar
        {
            B[i] = A[i];
        }
        i = izq;
        j = m + 1;
        k = izq;
        while (i <= m && j <= der) //copia el siguiente elemento más grande
        {
            if (B[i] <= B[j]) {
                A[k++] = B[i++];
            } else {
                A[k++] = B[j++];
            }
        }
        while (i <= m) //copia los elementos que quedan de la
        {
            A[k++] = B[i++]; 
        }
        imprime();
    }

    public static void main(String[] args) {
        Merge M = new Merge();
        M.imprime();
        M.mergesot(arr, 0, arr.length - 1);

    }

    private static void imprime() {
        for (int l = 0; l < arr.length; l++) {
            System.out.print(arr[l] + "\t");

        }
        System.out.println("\n");
    }
}
