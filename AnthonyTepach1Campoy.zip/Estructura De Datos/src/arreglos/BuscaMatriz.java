/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 *
 * @author DIN
 */
public class BuscaMatriz {

    int p[][] = new int[3][3];
    Scanner leer = new Scanner(System.in);

    private void llenar() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                System.out.print("cordenada " + i + "," + j + " = ");
                p[i][j] = leer.nextInt();
            }
        }
        busca();
    }

    public static void main(String[] args) {
        BuscaMatriz BM = new BuscaMatriz();
        BM.llenar();
    }

    /**
     * método que busca dentro de una matriz, un número que se le indique, la
     * busqueda es realizada mediante un FOR anidado y comparandolo con un if
     * para buscar coincidencias.Solo imprime los en que coordenada se encuentra
     * el número buscado.
     */
    private void busca() {
        imprime();
        System.out.print("\n\nA quien desea buscar: ");
        int num = leer.nextInt();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (num == p[i][j]) {
                    System.out.println(num + " se encuentra en la coordenada " + i + "," + j);
                }
            }

        }
    }

    private void imprime() {
        System.out.println("\n");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("\t" + p[i][j]);

            }
            System.out.println("");
        }
    }

}
