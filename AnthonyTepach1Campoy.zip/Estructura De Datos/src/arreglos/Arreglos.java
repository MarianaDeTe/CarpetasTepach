/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 *
 * @author AnthonyTepach
 */
public class Arreglos {

    Scanner s = new Scanner(System.in);
    int p[] = new int[5];
    /**
     * 
     */
    public void llenarArreglo() {
        int suma = 0,promedio=0;
        for (int i = 0; i < p.length; i++) {
            System.out.println("ingresa valor para el espacio " + (i + 1));
            p[i] = s.nextInt();

        }
        for (int i = 0; i < p.length; i++) {
            System.out.print(p[i]+" ");
             suma =suma+p[i];
             
            
        }
        System.out.println("\n\nLa Suma del arreglo es: "+suma);
        System.out.println("El promedio del arreglo es: " +(suma/p.length));
    }

    public static void main(String[] args) {
        Arreglos a = new Arreglos();
        a.llenarArreglo();
    }
}
