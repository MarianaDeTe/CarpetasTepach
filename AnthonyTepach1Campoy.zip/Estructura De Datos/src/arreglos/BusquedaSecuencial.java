package arreglos;

import java.util.Scanner;

/**
 *
 * @author AnthonyTepach
 */
public class BusquedaSecuencial {

    Scanner leer = new Scanner(System.in);
    int p[] = new int[5];

    public void llenar() {
        for (int i = 0; i < p.length; i++) {
            System.out.print("Número en la pocision " + i + " : ");
            p[i] = leer.nextInt();
        }
        busca();
    }

    public void busca() {
        System.out.print("A quien desea buscar: ");
        int num = leer.nextInt();
        for (int i = 0; i < p.length; i++) {
            if (num == p[i]) {
                System.out.println(num + " esta en la pocision " + i);
            }else{
                System.out.println("no se encuentra");
            }
        }
        

    }

    public static void main(String[] args) {
        BusquedaSecuencial BS = new BusquedaSecuencial();
        BS.llenar();

    }

}
