/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 *
 * @author AnthonyTepach
 */
public class Calificaciones {

    Scanner s = new Scanner(System.in);
    String tabla[]=new String[6];
    double calif[] = new double[4];
    double prom[] = new double[3];
    String alu[] = new String[3];

    public void ingresar() {

        for (int i = 0; i < alu.length; i++) {
            System.out.println("Nombre del alumno: ");
            alu[i] = s.next();
            for (int j = 0; j < calif.length; j++) {
                System.out.println("Calificaciion n° " + (j + 1));
                calif[i] = calif[i] + s.nextDouble();
                for (int k = 0; k < prom.length; k++) {
                    prom[i] = (calif[i] / calif.length);

                }
            }

        }
        imprime();
        
    }

    public static void main(String[] args) {
        Calificaciones c = new Calificaciones();
        c.ingresar();
    }

    private void imprime() {
        System.out.println("|-----------|-------------|");
        System.out.println("|  Alumno:  |   Promedio  |");
        System.out.println("|-----------|-------------|");
        for (int i = 0; i < alu.length; i++) {
            System.out.println("|-----------|-------------|");
            System.out.println("| " + alu[i] + "     | " + prom[i] + "     |");
        }
    }
}
