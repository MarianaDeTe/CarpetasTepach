package arreglos;

import java.util.Scanner;

public class QuickShort {

    static Scanner leer = new Scanner(System.in);
    static int a[] = {5, 3, 7, 6, 2, 1, 4,-9};

    /**
     * método que recibe tres parámetros, recibe a un arreglo de tipo entero el
     * cual se va a definir como pivote, las parámetros izq y der son posiciones
     * del arreglo izq recibe la primera posición del arreglo y der recibe la
     * ultima posición del arreglo.
     * @param A
     * @param izq
     * @param der
     */
    public static void quicksort(int A[], int izq, int der) {

        int pivote = A[izq];
        int i = izq+1;
        int j = der;
        int aux;
        imprime();
        
        while (i < j) {
            while (A[i] <= pivote && i < j) {
                i++;
            }
            while (A[j] > pivote) {
                j--;
            }
            if (i < j) {
                aux = A[i];
                A[i] = A[j];
                A[j] = aux;
            }
        }
        A[izq] = A[j];
        A[j] = pivote;
        if (izq < j - 1) {
            quicksort(A, izq, j - 1);
        }
        if (j + 1 < der) {
            quicksort(A, j + 1, der);
        }

    }
    /**
     * método que se encarga de imprimir el arreglo.
     */
    private static void imprime() {
        for (int i = 0; i < a.length; i++) {
            System.out.print("\t" + a[i]);

        }
        System.out.print("\n");
    }

    public static void main(String[] args) {
        QuickShort.quicksort(a, 0, a.length - 1);

    }

}
