
package arreglos;

import java.util.Scanner;
/**
 * 
 * @author AnthonyTepach
 */
public class SumaDeMatriz {

    Scanner leer = new Scanner(System.in);
    int a[][] = new int[3][3];
    int b[][] = new int[3][3];
    int c[][] = new int[3][3];
    
    public void llenar() {
        /**
         * pide y almacena los números para almacenarlos en su respectiva
         * posición mediante un for anidado de la matriz 'A'
         */
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                System.out.print("cordenadas de 'A' en " + i + "," + j + " = ");
                a[i][j] = leer.nextInt();
            }
        }
         /**
         * pide y almacena los números para almacenarlos en su respectiva
         * posición mediante un for anidado de la matriz 'B'
         */
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                System.out.print("cordenadas de 'B' en " + i + "," + j + " = ");
                b[i][j] = leer.nextInt();
            }
        }
        /**
         * Hace la suma de la matriz A[3][3] + B[3][3] y la almacena en una
         * tercera matriz C[3][3].segidamente lo imprime en forma de matriz.
         */
        System.out.println("Matriz de 'C'");
        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {
                c[i][j] = (a[i][j] + b[i][j]);
                System.out.print("\t" + c[i][j]);
            }
            System.out.println(" ");
        }
    }

    public static void main(String[] args) {

        SumaDeMatriz m = new SumaDeMatriz();
        m.llenar();
    }

}
