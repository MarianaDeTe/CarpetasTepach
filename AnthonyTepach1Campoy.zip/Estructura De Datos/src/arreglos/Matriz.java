package arreglos;

import java.util.Scanner;

public class Matriz {

    int p[][] = new int[4][5];
    Scanner leer=new Scanner(System.in);

    public void llenar() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j<5; j++) {
               
                System.out.print("cordenada "+i+","+j+" = ");
                p[i][j]=leer.nextInt();
            }
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("\t"+p[i][j]);
                
            }
            System.out.println("");
        }
    }

    public static void main(String[] args) {

        Matriz m = new Matriz();
        m.llenar();
    }
}
