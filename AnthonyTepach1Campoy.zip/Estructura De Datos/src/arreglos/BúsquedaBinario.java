/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos;

import java.util.Scanner;

/**
 *
 * @author anthonytepach
 */
public class BúsquedaBinario {

    Scanner leer = new Scanner(System.in);
    int arreglo[] = new int[6];

    public void llenar() {
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = i + 1;

        }
        int centro = (arreglo.length / 2);
        System.out.println("ingresa numero a buscar");
        int num = leer.nextInt();
        busca(centro, num);
    }

    public void busca(int cent, int buscaA) {
        if (arreglo[cent] == buscaA) {
            System.out.println("El número buscado esta en la posición " + arreglo[--cent]);
        } else if (buscaA < arreglo[cent]) {
            for (int i = 0; i < arreglo[cent]; i++) {
                if (buscaA == arreglo[i]) {
                    System.out.println("El número " + buscaA + " buscado esta en la posición " + i);
                }
            }
        } else if (buscaA > arreglo[cent]) {
            String ec = null;
            int i = arreglo[cent];
            while (buscaA != i) {
                 ec="El número " + buscaA + " buscado esta en la posición "+String.valueOf(i);
                i++;
            }
            System.out.println(ec);
        }

    }

    public static void main(String[] args) {
        BúsquedaBinario bb = new BúsquedaBinario();
        bb.llenar();
    }
}
