/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodo;

/**
 *Vazquez Garcia Mariana Karina
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Lista l = new Lista();
        l.InsertarInicio("M");
        l.InsertarFinal("a");
        l.InsertarFinal("r");
        l.InsertarFinal("i");
        l.InsertarFinal("a");
        l.InsertarFinal("n");
        l.InsertarFinal("a");
//        l.InsertarInicio("a");

        l.Listar();
        System.out.println();
        l.EliminarInicio();
        l.Listar();
        System.out.println();
    }
}
