/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodo;

/**
 * Vazquez Garcia Mariana Karina
 */
public class Lista {
    Nodo inicio, fin;
    
    public Lista(){
        inicio = null;
        fin = null;
    }
    
    public void InsertarInicio(String info){
        Nodo nuevo = new Nodo(info, inicio);
        inicio = nuevo;
        
        if (fin == null) {
            fin = inicio;
        }
    }
    
    public void InsertarFinal(String info){
        Nodo nuevo = new Nodo(info, null);
        if (inicio == null) {
            fin = nuevo;
            inicio = fin;
        }else{
            fin.setSig(nuevo);
            fin = nuevo;
        }
    }
    
    public void EliminarInicio(){
        inicio = inicio.sig;
    }
    
    public String ExtraerInicio(){
        String info = inicio.getInfo();
        inicio = inicio.getSig();
        
        if (inicio == null) {
            fin = null;
        }
        return info;
    }
    
    public void Listar(){
        Nodo temp = inicio;
        while(temp != null){
            System.out.println(temp.getInfo());
            temp = temp.sig;
        }
    }
}
