/**
 * UN MAESTRO DE EDUCACION BASICA
 */
package tarea;

import java.util.Scanner;

public class Programa1 {

    Scanner leer = new Scanner(System.in);
    static String[] Nombre = new String[5];
    static String[] matricula = new String[5];
    static String[] Calificacion = new String[5];
    int contar = 0;
    int opc = 0;

    /**
     * Método el cual muestra un menú de lo que desea hacer el MAESTRO y
     * contiene un switch donde se mandan a llamar los métodos insertarAlumno(),
     * eliminarAlumno(), mostrarAlumno()
     */
    public void menu() {
        int op = 0;
        while (op <= 4) {
            do {
                System.out.println("¿Qué desea hacer?: \n "
                        + " 1) Insertar Alumno \n "
                        + " 2) Eliminar Alumno \n "
                        + " 3) Mostrar Alumnos \n "
                        + " 4) Salir");
                try {
                    opc = leer.nextInt();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } while (opc <= 0 || opc >= 5);
            switch (opc) {
                case 1:
                    insertarAlumno();
                    break;
                case 2:
                    eliminarAlumno();
                    break;
                case 3:
                    mostrarAlumno();
                    break;
                case 4:

                    break;

            }
        }
    }

    /**
     * método que pide a alumno, matricula y la calificacion y los guarda en la
     * pocision que le corresponda siempre y cuando la la variable contar sea menor a 3
     */
    private void insertarAlumno() {
        if (contar < 3) {

            System.out.println("Ingresa el Nombre del alumno: ");
            Nombre[contar] = leer.next();

            System.out.println("Ingresa la Matricula: ");
            matricula[contar] = leer.next();

            System.out.println("Ingresa la Calificacion: ");
            Calificacion[contar] = leer.next();

            contar++;
        } else {
            System.out.println("Ya no puedes ingresar más alumnos");
        }
    }

    public static void main(String args[]) {
        Programa1 p = new Programa1();
        p.menu();
    }

    private void eliminarAlumno() {
        String eliminarMatricula = "";
        int recorrer = 0;

        if (contar > 0) {

            try {
                System.out.println("Ingresa la matricula : ");
                eliminarMatricula = leer.next();
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (int i = 0; i < contar; i++) {
                if (matricula[i].equals(eliminarMatricula)) {
                    recorrer++;
                    for (int j = i; j < contar; j++) {

                        Nombre[j] = Nombre[j + 1];
                        matricula[j] = matricula[j + 1];
                        Calificacion[j] = Calificacion[j + 1];
                    }
                    i--;
                    contar--;
                }
            }
            if (recorrer > 0) {
                System.out.println("Se a eliminado el Alumno");
            } else {
                System.out.println("Tienes que ingresar la matricula para eliminar");
            }
        } else {
            System.out.println("No hay Estudiantes");
        }
    }

    private void mostrarAlumno() {
        if (contar > 0) {
            System.out.println(" matricula   Calificacion   Nombre");
        } else {
            System.out.println("no se han llenado los espacios\n");
        }
        for (int i = 0; i < contar; i++) {
            System.out.print(matricula[i] + "\t");
            System.out.print(Calificacion[i] + "\t  ");
            System.out.print(Nombre[i] + "");
            System.out.println("\n");
        }
    }

}
