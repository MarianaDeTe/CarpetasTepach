/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recirsividad;

import java.util.Scanner;

/**
 *
 * @author Anthony Tepach
 */
public class Tabla {

    Scanner halo = new Scanner(System.in);

    /**
     * Método que recibe como parametros "a y b" donde a es ta tabla que se
     * quiere mostrar y siempre va a ser 10;
     *
     * @param a
     * @param b
     * @return
     */
    int tabla(int a, int b) {
        if (b == 0) {//caso base;cualquier número multiplicado por cero es 0
            return 0;
        } else {
            System.out.println(a + "*" + b + "=" + a * b);
            return tabla(a, b - 1);
        }
    }

    /**
     * puide la tabla que se quiere mostar e imprime la tabla
     */
    public void leerImprimir() {
        System.out.print("Tabla a mostrar: ");
        int a = halo.nextInt();
        tabla(a, 10);
    }

    public static void main(String[] args) {
        Tabla ppt = new Tabla();
        ppt.leerImprimir();

    }
}
