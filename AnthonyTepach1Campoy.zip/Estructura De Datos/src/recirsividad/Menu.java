/**
 * AUTOR: ANTHONY TEPACH
 */
package recirsividad;

import java.util.Scanner;

public class Menu {

    Scanner halo = new Scanner(System.in);

    char o = 0;

    public void todo() {
        System.out.println("-*--*-MENÚ-*--*-");
        System.out.println("a). Suma de Números Sucesivos  \nb). Potencia\nc). Fibonacci\nd). Division mediante resta\ne). Producto mediante suma\nf). Tablas de multiplicar.\ng). Salir");
        System.out.println("Elige una opción");
        o = halo.next().charAt(o);
        ejecutar(o);
    }

    public static void main(String[] args) {
        Menu m = new Menu();
        m.todo();
    }

    private void ejecutar(char w) {
        switch (w) {
            case 'a':
            case 'A':
                System.out.println("SUMA DE NÚMEROS SUCESIVOS");
                Suma s = new Suma();
                s.leerImprimir();
                todo();
                break;

            case 'b':
            case 'B':
                System.out.println("POTENCIA");
                Potencia p = new Potencia();
                p.leerImprimir();
                todo();
                break;
            case 'c':
            case 'C':
                System.out.println("FIBONACCI");
                Fibonacci f = new Fibonacci();
                f.leerImprimir();
                todo();
                break;
            case 'd':
            case 'D':
                System.out.println("DIVISION MEDIANTE RESTAS");
                Division d = new Division();
                d.leerImprimir();
                todo();
                break;
            case 5:
            case 'e':
            case 'E':
                System.out.println("MULTIPLICACION MEDIANTE SUMA");
                ProductMedianteSuma m = new ProductMedianteSuma();
                m.leerImprimir();
                todo();
                break;
            case 'f':
            case 'F':
                System.out.println("TABLAS DE MULTIPLICACION");
                Tabla t = new Tabla();
                t.leerImprimir();
                todo();
                break;
            case 'g':
            case 'G':
                System.exit(0);
                break;
            default:
                System.out.println("No Existe esa opcion, favor de verificar.\n");
                todo();
                break;
        }
    }
}
