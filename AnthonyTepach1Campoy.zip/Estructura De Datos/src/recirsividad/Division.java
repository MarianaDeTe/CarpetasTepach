/**
 * AUTOR:   AnthonyTepach. GRUPO: 4TIC1
 * TITULO:  Divisiones Mediante Resta
 */
package recirsividad;

import java.util.Scanner;

public class Division {

    Scanner halo = new Scanner(System.in);

    /**
     * Método recursivo que resive como parametros 2 valores de tipo entero ,donde "a" es
     * el dividendo y "b"es el divisor
     *
     * @param a
     * @param b
     * @return
     */
    int division(int a, int b) {
        if (b > a) {//caso base. si el divisor es mayor al dividendo retorna 0
            return 0;
        } else {
            System.out.println("a= "+ a+ " b= "+b);
            return division(a - b, b)+1;
        }
    }

    /**
     * El método leerImprimir() simplemente pide los números a dividir e imprime
     * el resultado de dicha operación, no cuenta con un tipo de retorno
     * especial.
     */
    public void leerImprimir() {
        System.out.println("Escribe el dividendo: ");
        int dividendo = halo.nextInt();
        System.out.println("Escribe el divisor: ");
        int divisor = halo.nextInt();

        System.out.println(dividendo + " / " + divisor + " = " + division(dividendo, divisor));

    }

    public static void main(String[] args) {
        Division es = new Division();
        es.leerImprimir();

    }
}
