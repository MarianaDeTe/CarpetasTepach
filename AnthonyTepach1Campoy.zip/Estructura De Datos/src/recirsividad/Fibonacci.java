/**
 * AUTOR: AnthonyTepach.
 * GRUPO: 4TIC1
 * TITULO: serie fibonacci.
 */
package recirsividad;

import java.util.Scanner;

public class Fibonacci {

    Scanner halo = new Scanner(System.in);

    /**
     * método recursivo que recibe como paramero a "n" de tipo entero donde "n"
     * son las posiciones.
     *
     * @param n
     * @return
     */
    static long fibo(long n) {
        if (n == 0 || n == 1) {    
           
            return 1;
        } else {
            return fibo(n - 1) + fibo(n - 2);  //Progreso del codigo
        }
    }

    /**
     * El método leerImprimir() simplemente pide la posicion que desea saber e
     * imprime el la serie hasta esa posición, no cuenta con un tipo de retorno
     * especial.
     */
    /**
     * 
     */
    public void leerImprimir() {
        System.out.println("\nEscribe hasta que posicion desea saber: ");
        int x = halo.nextInt();
//        fibo(x);
        int posi = 0;

        System.out.println("el fibonacci de " + x + " es: ");
        System.out.println("0");
        while (posi != x) {
            System.out.println(fibo(posi));
            posi++;

        }

        leerImprimir();

    }

    public static void main(String[] args) {
        Fibonacci ppt = new Fibonacci();
        ppt.leerImprimir();

    }
}
