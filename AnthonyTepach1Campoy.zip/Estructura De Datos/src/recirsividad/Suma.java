/**
 * AUTOR: AnthonyTepach. GRUPO: 4TIC1 TITULO: Suma de Números
 */
package recirsividad;

import java.util.Scanner;

public class Suma {

    /**
     * la declariación de la variable "x" permite guardar el valor del numero
     * introducido por el usuario. para posteriormente mandarlo al método
     * "suma(x)".
     */
    int x;
    Scanner halo = new Scanner(System.in);

    /**
     * "suma(int n)" Es un método recursivo con tipo de retorno int, el cual
     * obtiene la suma de los primeros "n" numeros de un número como Recibiendo
     * como parámetro a un número de tipo entero “n”,el cual efectúa la
     * operación "n+suma(n-1)", el método se detiene cuando llegue a su caso
     * base el cual es 1.
     *
     * @param n
     * @return
     */
    static int suma(int n) {
        if (n == 1) {//caso base
            return 1;
        } else {
            return n + suma(n - 1);//Progreso del codigo
        }
    }

    /**
     * El método leer() simplemente pide el número al que se desea sacar la suma
     * de los números , E imprimir la suma de los primeros números de dicho
     * numero, no cuenta con un tipo de retorno especial.
     */
    public void leerImprimir() {
        System.out.println("Escribe un número: ");
        x = halo.nextInt();
        System.out.println("suma de los primeros : " + x + " números es: " + suma(x));
        System.out.println("\n");
        leerImprimir();

    }

    public static void main(String[] args) {
        Suma es = new Suma();
        es.leerImprimir();

    }
}
