/**
 * AUTOR: AnthonyTepach. GRUPO: 4TIC1
 */


package recirsividad;

import java.util.Scanner;

public class EstructuraDeDatos {

    int x;
    Scanner halo = new Scanner(System.in);


/**
 * "facto(int n)" Es un método recursivo el cual obtiene el factorial de un
 * número como Recibiendo como parámetro a un número de tipo entero
 * “n”, el método se detiene cuando llegue a su caso base el cual es 1.
 * @param n
 * @return 
 */
    static int facto(int n) {
        if (n == 1) { //caso base 
            return 1;
        } else {
            return n * facto(n - 1);//Progreso del codigo
        }
    }

    /**
     * El método leerImprimir() simplemente pide el número que se quiere sacar
     * factorial e imprime el resultado de dicha operación, no cuenta con un
     * tipo de retorno especial.
     */
    public void leerImprimir() {
        System.out.println("Escribe un numero: ");
        x = halo.nextInt();
        System.out.println("el factorial de: " + x + " es: " + facto(x));

    }

    public static void main(String[] args) {
        EstructuraDeDatos es = new EstructuraDeDatos();
        es.leerImprimir();

    }

}
