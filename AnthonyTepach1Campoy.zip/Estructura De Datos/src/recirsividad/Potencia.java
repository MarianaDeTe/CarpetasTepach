/**
 * AUTOR: AnthonyTepach. 
 * GRUPO: 4TIC1 
 * TITULO: Potencia de un número.
 */
package recirsividad;

import java.util.Scanner;

public class Potencia {

    Scanner halo = new Scanner(System.in);

    /**
     * Método recursivo el cual calcula la potencia de un número “n”, el cual
     * recibe como parámetros “b” el cual es la base y “p” es la potencia a la
     * que se quiere elevar, cuyo caso base es 0 y retorna el valor 1 porque la
     * potencia de “n a la cero=1” donde “n” es cualquier número.
     *
     * @param b
     * @param p
     * @return
     */
    static int pote(int b, int p) {
        if (p == 0) {                   //caso base
            return 1;
        } else {
            return b * pote(b, p - 1);  //Progreso del codigo
        }
    }

    /**
     * Método que no devuelve ningún valor específico, solo se encarga de pedir
     * los valores al usuario,guardarlos e imprimirlos.
     */
    public void leerImprimir() {
        String res = "N";
        
            System.out.print("Base: ");
            int b = halo.nextInt();
            System.out.print("Potencia: ");
            int p = halo.nextInt();
            System.out.println("La potencia de " + b + " elevado a la " + p + " es: " + pote(b, p));
            System.out.println("Desea seguir calculando más potencias[S/N]");
            res = halo.next();
            if (res.equalsIgnoreCase("s")) {
            leerImprimir();
        }else{
            System.exit(0);
            }
    }

    public static void main(String[] args) {
        Potencia ppt = new Potencia();
        ppt.leerImprimir();
    }
}
