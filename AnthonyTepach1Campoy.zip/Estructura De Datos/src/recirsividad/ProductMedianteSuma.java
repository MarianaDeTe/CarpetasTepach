/**
 * AUTOR: AnthonyTepach.
 * GRUPO: 4TIC1
 * TITULO: ProductMedianteSuma.
 */
package recirsividad;

import java.util.Scanner;

public class ProductMedianteSuma {

    Scanner halo = new Scanner(System.in);

    /**
     * Método recursivo el cual calcula la multiplicacion mediante la suma de
     * "b+b" el cual es un parametro que recibe.y cuando "a" llege a 0 de
     * detiene el proceso
     *
     * @param a
     * @param b
     * @return
     */
    int productMedianteSuma(int a, int b) {
        if (a == 0) {//caso base
            return 0;
        } else {
//            System.out.println("a=" + a + " b=" + b);
            return productMedianteSuma(a - 1, b) + b;//proceso del código
        }

    }

    /**
     * El método leerImprimir() simplemente pide el número de la tabla deseada e
     * imprime el resultado de dicha operación, no cuenta con un tipo de retorno
     * especial.
     */
    public void leerImprimir() {
        System.out.println("Número a Multiplicar: ");
        int a = halo.nextInt();
        System.out.print("por: ");
        int b = halo.nextInt();
        System.out.println(a + " * " + b + " = " + productMedianteSuma(a, b));
    }

    public static void main(String[] args) {
        ProductMedianteSuma ppt = new ProductMedianteSuma();
        ppt.leerImprimir();

    }
}
